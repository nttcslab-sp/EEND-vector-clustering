This archive contains the following set of log files generated through the training, adaptation, and evaluation.

1. Log file (standard output, standard error output) obtained when executing ./run.sh
2. Log file of the neural network training based on simulated data
3. Log file obtained when saving speaker embedding vectors (that will be used for adaptation)
4. Log file obtained when adapting the neural network to switchboard data
5. Log file obtained when inference


The size and name of each log file are summarized below.

1. 25M     log.run.txt
2. 324K    exp/diarize/model/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/.work/train.log
3. 4.0K    exp/diarize/model/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/avg91-100.callhome1_spkall.adapt/save_spkv_lab/.work/save_spkv_lab.log
4. 48K     exp/diarize/model/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/avg91-100.callhome1_spkall.adapt/.work/train.log
5.
32K     exp/diarize/infer/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/avg91-100.callhome1_spkall.adapt.avg21-25.infer_est_nspk0/callhome2_spk2/.work/infer.log
24K     exp/diarize/infer/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/avg91-100.callhome1_spkall.adapt.avg21-25.infer_est_nspk0/callhome2_spk3/.work/infer.log
16K     exp/diarize/infer/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/avg91-100.callhome1_spkall.adapt.avg21-25.infer_est_nspk0/callhome2_spk4/.work/infer.log
8.0K    exp/diarize/infer/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/avg91-100.callhome1_spkall.adapt.avg21-25.infer_est_nspk0/callhome2_spk5/.work/infer.log
8.0K    exp/diarize/infer/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/avg91-100.callhome1_spkall.adapt.avg21-25.infer_est_nspk0/callhome2_spk6/.work/infer.log
68K     exp/diarize/infer/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/avg91-100.callhome1_spkall.adapt.avg21-25.infer_est_nspk0/callhome2_spkall/.work/infer.log
40K     exp/diarize/infer/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/avg91-100.callhome1_spkall.adapt.avg21-25.infer_est_nspk1/callhome2_spk2/.work/infer.log
28K     exp/diarize/infer/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/avg91-100.callhome1_spkall.adapt.avg21-25.infer_est_nspk1/callhome2_spk3/.work/infer.log
16K     exp/diarize/infer/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/avg91-100.callhome1_spkall.adapt.avg21-25.infer_est_nspk1/callhome2_spk4/.work/infer.log
8.0K    exp/diarize/infer/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/avg91-100.callhome1_spkall.adapt.avg21-25.infer_est_nspk1/callhome2_spk5/.work/infer.log
8.0K    exp/diarize/infer/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/avg91-100.callhome1_spkall.adapt.avg21-25.infer_est_nspk1/callhome2_spk6/.work/infer.log
80K     exp/diarize/infer/swb_sre_tr_ns3_beta10_100000.swb_sre_cv_ns3_beta10_500.train/avg91-100.callhome1_spkall.adapt.avg21-25.infer_est_nspk1/callhome2_spkall/.work/infer.log